# Playbooks for setting up GlusterFS and related usecases

This directory will contain playbooks and related documentation for setting up GlusterFS usecases.
