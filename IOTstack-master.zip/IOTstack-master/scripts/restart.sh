docker-compose restart
