docker system prune --volumes

