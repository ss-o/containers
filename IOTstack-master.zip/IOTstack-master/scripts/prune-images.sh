docker image prune -a
