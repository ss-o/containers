# GNAS emr lsio remote Linuxserver.io Portainer Stack

This directory contains the docker-compose.yml and supporting files needed to construct
a Portainer Stack running the following applications:
  - bazarr
  - hydra2
  - jackett
  - jellyfin
  - lidarr
  - nzbget
  - plex
  - qbittorrent
  - radarr
  - sonarr
