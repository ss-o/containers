# GNAS Classic Linuxserver.io Portainer Stack

This directory contains the docker-compose.yml and supporting files needed to construct
a Portainer Stack running the following applications:
  - jackett
  - hydra2
  - sabnzbd
  - transmission
  - couchpotato
  - sickgear
  - headphones
  - tvheadend
  - kodi_headless
  - mysql
  - openvpn_as
