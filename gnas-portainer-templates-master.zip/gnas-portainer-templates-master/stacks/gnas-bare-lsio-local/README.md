# GNAS Bare Linuxserver.io Portainer Stack with Local Templates

This directory contains the docker-compose.yml and supporting files needed to construct
a Portainer Stack running the following applications:
  - portainer-templates
  - portainer-app
