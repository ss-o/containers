# GNAS Bare Linuxserver.io Portainer Stack with Remote Templates

This directory contains the docker-compose.yml and supporting files needed to construct
a Portainer Stack running the following applications:
  - portainer-app
