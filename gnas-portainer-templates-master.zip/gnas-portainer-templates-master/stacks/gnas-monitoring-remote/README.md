# GNAS Prometheus Monitoring Portainer Stack

This directory contains the docker-compose.yml and supporting files needed to construct
a Portainer Stack running the following applications:
  - cadvisor
  - prometheus
  - alertmanager
  - pushgateway
  - grafana
  - sabnzbd_exporter
  - transmission_exporter
